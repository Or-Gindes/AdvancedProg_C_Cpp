#ifndef DEFS_H_
#define DEFS_H_

#include <iostream>
#include <string.h>
#include <string>

typedef enum e_status { success, failure, BadMemoryAllocation, BadArgs } status ;

#endif /* DEFS_H_ */